using TMPro;
using UnityEngine;

public class UIManager : MonoBehaviour
{
    public TMP_Text scoreText; 
    public TMP_Text livesText;

    private int score = 0;
    private int lives = 3;

    public void UpdateScore(int value)
    {
        score += value;
        scoreText.text = "Score: " + score;
    }

    public void UpdateLives(int value)
    {
        lives += value;
        livesText.text = "Lives: " + lives;
    }
}
